/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package util;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;

/**
 * MongoDB Connection Helper
 * Part of 3-Tier Architecture: Data Access Layer (Utility)
 * 
 * @author Vihanga Ranaweera
 */
public class MongoConnection {

    private static MongoClient client;

    public static MongoDatabase getDatabase() {
        if (client == null) {
            String uri = System.getenv("MONGODB_URI");
            if (uri == null || uri.isEmpty()) {
                uri = "mongodb://localhost:27017";
            }
            client = MongoClients.create(uri);
        }
        String dbName = System.getenv("MONGODB_DB");
        if (dbName == null || dbName.isEmpty()) {
            dbName = "library_db";
        }
        return client.getDatabase(dbName);
    }

    public static void close() {
        if (client != null) {
            client.close();
            client = null;
        }
    }
}
