/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 * Main Application Entry Point
 * Part of 3-Tier Architecture: This initializes all layers
 * 
 * To run with MySQL:  Set BACKEND=mysql environment variable
 * To run with MongoDB: Set BACKEND=mongo environment variable
 * 
 * @author Vihanga Ranaweera
 */
import dao.*;
import gui.*;
import service.LibraryService;
import util.MongoConnection;
import util.MySQLConnection;

import com.mongodb.client.MongoDatabase;

public class Main {
    public static void main(String[] args) {

        // Choose backend using environment variable BACKEND: "mysql" or "mongo"
        String backend = System.getenv("BACKEND");

        if ("mysql".equalsIgnoreCase(backend)) {
            // ========== MySQL Backend ==========
            System.out.println("Starting Library System with MySQL backend...");
            
            java.sql.Connection conn = MySQLConnection.getConnection();
            
            LoanDAO loanDAO = new LoanDAOMySQL(conn);
            FineDAO fineDAO = new FineDAOMySQL(conn);
            
            LibraryService service = new LibraryService(loanDAO, fineDAO);
            
            new BorrowForm(service);
            new FinePaymentForm(service);
            new LoanReportForm(new ReportDAOMySQL(conn));
            new FineReportForm(new FineReportDAOMySQL(conn));
            
        } else if ("mongo".equalsIgnoreCase(backend)) {
            // ========== MongoDB Backend ==========
            System.out.println("Starting Library System with MongoDB backend...");
            
            MongoDatabase db = MongoConnection.getDatabase();
            
            LoanDAO loanDAO = new LoanDAOMongo(db.getCollection("loans"));
            FineDAO fineDAO = new FineDAOMongo(db.getCollection("finePayments"));
            
            LibraryService service = new LibraryService(loanDAO, fineDAO);
            
            new BorrowForm(service);
            new FinePaymentForm(service);
            new LoanReportForm(new ReportDAOMongo(db.getCollection("loans")));
            new FineReportForm(new FineReportDAOMongo(db.getCollection("finePayments")));
            
        } else {
            // No backend specified - show usage
            System.out.println("===========================================");
            System.out.println("Library System - Database Selection");
            System.out.println("===========================================");
            System.out.println("Please set BACKEND environment variable:");
            System.out.println("  BACKEND=mysql  -> Use MySQL database");
            System.out.println("  BACKEND=mongo  -> Use MongoDB database");
            System.out.println("");
            System.out.println("Example:");
            System.out.println("  $env:BACKEND='mongo'; java -cp 'build/classes;lib/*' Main");
            System.out.println("===========================================");
        }
    }
}
