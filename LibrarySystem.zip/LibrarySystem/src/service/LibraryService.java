/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

/**
 *
 * @author Vihanga Ranaweera
 */
import dao.FineDAO;
import dao.LoanDAO;

public class LibraryService {

    LoanDAO loanDAO;
    FineDAO fineDAO;

    public LibraryService(LoanDAO loanDAO, FineDAO fineDAO) {
        this.loanDAO = loanDAO;
        this.fineDAO = fineDAO;
    }

    public void borrowBook(String studentId, String bookId) {
        loanDAO.borrowBook(studentId, bookId);
    }

    public void returnBook(String studentId, String bookId) {
        loanDAO.returnBook(studentId, bookId);
    }

    public void payFine(String studentId, double amount) {
        fineDAO.payFine(studentId, amount);
    }
}

