/*
 * Fine Report DAO Interface - Abstraction for fine reports
 * Part of 3-Tier Architecture: Data Access Layer
 */
package dao;

/**
 * Interface for generating fine payment reports.
 * Implementations exist for both MySQL (relational) and MongoDB (NoSQL).
 * 
 * @author Vihanga Ranaweera
 */
public interface FineReportDAO {
    
    /**
     * Gets the total fine paid by a student in a specific month.
     * 
     * @param studentId The student's ID
     * @param month The month number (1-12)
     * @return Total fine amount paid
     */
    double getTotalFine(String studentId, int month);
}
