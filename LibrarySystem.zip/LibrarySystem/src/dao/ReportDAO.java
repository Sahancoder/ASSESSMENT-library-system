/*
 * Report DAO Interface - Abstraction for loan history reports
 * Part of 3-Tier Architecture: Data Access Layer
 */
package dao;

import javax.swing.JTable;

/**
 * Interface for generating loan history reports.
 * Implementations exist for both MySQL (relational) and MongoDB (NoSQL).
 * 
 * @author Vihanga Ranaweera
 */
public interface ReportDAO {
    
    /**
     * Gets the loan history for a student in a specific month.
     * 
     * @param studentId The student's ID
     * @param month The month number (1-12)
     * @return JTable containing loan history data
     */
    JTable getLoanHistory(String studentId, int month);
}
