/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 * MySQL implementation of FineReportDAO - Relational Database approach.
 * Uses SQL aggregate function SUM() for calculating totals.
 *
 * @author Vihanga Ranaweera
 */
import java.sql.*;

public class FineReportDAOMySQL implements FineReportDAO {

    Connection conn;

    public FineReportDAOMySQL(Connection conn) {
        this.conn = conn;
    }

    public double getTotalFine(String studentId, int month) {
        try {
            String sql = "SELECT SUM(amount) FROM FINE_PAYMENT WHERE student_id=? AND MONTH(payment_date)=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, studentId);
            ps.setInt(2, month);
            ResultSet rs = ps.executeQuery();
            if(rs.next()) return rs.getDouble(1);
        } catch(Exception e){ e.printStackTrace(); }
        return 0;
    }
}

