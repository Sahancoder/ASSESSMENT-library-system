/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import com.mongodb.client.MongoCollection;
import org.bson.Document;

/**
 * MongoDB implementation of FineDAO
 * Part of 3-Tier Architecture: Data Access Layer
 * Demonstrates NoSQL document-based storage for fine payments.
 * 
 * @author Vihanga Ranaweera
 */
public class FineDAOMongo implements FineDAO {

    private final MongoCollection<Document> finePayments;

    public FineDAOMongo(MongoCollection<Document> finePayments) {
        this.finePayments = finePayments;
    }

    @Override
    public void payFine(String studentId, double amount) {
        Document doc = new Document("studentId", studentId)
                .append("amount", amount)
                .append("paymentDate", java.time.LocalDate.now().toString());
        finePayments.insertOne(doc);
    }
}
