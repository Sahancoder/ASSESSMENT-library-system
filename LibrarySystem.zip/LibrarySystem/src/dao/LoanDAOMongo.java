/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import com.mongodb.client.MongoCollection;
import org.bson.Document;

import static com.mongodb.client.model.Filters.and;
import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Updates.combine;
import static com.mongodb.client.model.Updates.set;

/**
 * MongoDB implementation of LoanDAO
 * Part of 3-Tier Architecture: Data Access Layer
 * Demonstrates NoSQL document-based storage for loan records.
 * 
 * @author Vihanga Ranaweera
 */
public class LoanDAOMongo implements LoanDAO {

    private final MongoCollection<Document> loans;

    public LoanDAOMongo(MongoCollection<Document> loans) {
        this.loans = loans;
    }

    @Override
    public void borrowBook(String studentId, String bookId) {
        Document doc = new Document("studentId", studentId)
                .append("bookId", bookId)
                .append("borrowDate", java.time.LocalDate.now().toString())
                .append("returnDate", null)
                .append("status", "Borrowed");
        loans.insertOne(doc);
    }

    @Override
    public void returnBook(String studentId, String bookId) {
        loans.updateOne(
            and(eq("studentId", studentId), eq("bookId", bookId), eq("status", "Borrowed")),
            combine(
                set("status", "Returned"),
                set("returnDate", java.time.LocalDate.now().toString())
            )
        );
    }
}
