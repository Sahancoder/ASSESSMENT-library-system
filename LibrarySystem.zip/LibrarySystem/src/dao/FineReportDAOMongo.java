/*
 * MongoDB Fine Report DAO - NoSQL implementation for fine reports
 * Part of 3-Tier Architecture: Data Access Layer
 */
package dao;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import org.bson.Document;

import static com.mongodb.client.model.Filters.eq;

/**
 * MongoDB implementation of FineReportDAO
 * Demonstrates NoSQL document-based aggregation for fine totals.
 * 
 * @author Vihanga Ranaweera
 */
public class FineReportDAOMongo implements FineReportDAO {

    private final MongoCollection<Document> finePayments;

    public FineReportDAOMongo(MongoCollection<Document> finePayments) {
        this.finePayments = finePayments;
    }

    @Override
    public double getTotalFine(String studentId, int month) {
        double total = 0.0;

        // Query all fine payments for this student
        try (MongoCursor<Document> cursor = finePayments.find(eq("studentId", studentId)).iterator()) {
            while (cursor.hasNext()) {
                Document doc = cursor.next();
                String paymentDate = doc.getString("paymentDate");
                
                // Filter by month (paymentDate format: YYYY-MM-DD)
                if (paymentDate != null && !paymentDate.isEmpty()) {
                    String[] parts = paymentDate.split("-");
                    if (parts.length >= 2) {
                        int docMonth = Integer.parseInt(parts[1]);
                        if (docMonth == month) {
                            Double amount = doc.getDouble("amount");
                            if (amount != null) {
                                total += amount;
                            }
                        }
                    }
                }
            }
        }

        return total;
    }
}
