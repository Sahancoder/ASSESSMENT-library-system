/*
 * MongoDB Report DAO - NoSQL implementation for loan history reports
 * Part of 3-Tier Architecture: Data Access Layer
 */
package dao;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import org.bson.Document;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import static com.mongodb.client.model.Filters.eq;

/**
 * MongoDB implementation of ReportDAO
 * Demonstrates NoSQL document-based querying for loan history.
 * 
 * @author Vihanga Ranaweera
 */
public class ReportDAOMongo implements ReportDAO {

    private final MongoCollection<Document> loans;

    public ReportDAOMongo(MongoCollection<Document> loans) {
        this.loans = loans;
    }

    @Override
    public JTable getLoanHistory(String studentId, int month) {
        DefaultTableModel model = new DefaultTableModel(
            new String[]{"Book ID", "Borrow Date", "Return Date", "Status"}, 0);

        // Query all loans for this student
        try (MongoCursor<Document> cursor = loans.find(eq("studentId", studentId)).iterator()) {
            while (cursor.hasNext()) {
                Document doc = cursor.next();
                String borrowDate = doc.getString("borrowDate");
                
                // Filter by month (borrowDate format: YYYY-MM-DD)
                if (borrowDate != null && !borrowDate.isEmpty()) {
                    String[] parts = borrowDate.split("-");
                    if (parts.length >= 2) {
                        int docMonth = Integer.parseInt(parts[1]);
                        if (docMonth == month) {
                            model.addRow(new Object[]{
                                doc.getString("bookId"),
                                borrowDate,
                                doc.getString("returnDate") != null ? doc.getString("returnDate") : "",
                                doc.getString("status")
                            });
                        }
                    }
                }
            }
        }

        return new JTable(model);
    }
}
