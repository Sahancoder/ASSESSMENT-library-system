/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 *
 * @author Vihanga Ranaweera
 */
import java.sql.Connection;
import java.sql.PreparedStatement;

public class LoanDAOMySQL implements LoanDAO {

    Connection conn;

    public LoanDAOMySQL(Connection conn) {
        this.conn = conn;
    }

    @Override
    public void borrowBook(String studentId, String bookId) {
        try {
            String sql = "INSERT INTO LOAN(student_id, book_id, borrow_date, status) VALUES (?, ?, CURDATE(), 'Borrowed')";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, studentId);
            ps.setString(2, bookId);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void returnBook(String studentId, String bookId) {
        try {
            String sql = "UPDATE LOAN SET return_date = CURDATE(), status='Returned' WHERE student_id=? AND book_id=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, studentId);
            ps.setString(2, bookId);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
