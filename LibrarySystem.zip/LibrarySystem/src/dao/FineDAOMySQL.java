/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 *
 * @author Vihanga Ranaweera
 */
import java.sql.Connection;
import java.sql.PreparedStatement;

public class FineDAOMySQL implements FineDAO {

    Connection conn;

    public FineDAOMySQL(Connection conn) {
        this.conn = conn;
    }

    @Override
    public void payFine(String studentId, double amount) {
        try {
            String sql = "INSERT INTO FINE_PAYMENT(student_id, amount, payment_date) VALUES (?, ?, CURDATE())";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, studentId);
            ps.setDouble(2, amount);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
