/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 * MySQL implementation of ReportDAO - Relational Database approach.
 * Uses SQL JOINs and WHERE clauses for querying loan history.
 *
 * @author Vihanga Ranaweera
 */
import java.sql.*;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class ReportDAOMySQL implements ReportDAO {

    Connection conn;

    public ReportDAOMySQL(Connection conn) {
        this.conn = conn;
    }

    public JTable getLoanHistory(String studentId, int month) {
        DefaultTableModel model = new DefaultTableModel(
            new String[]{"Book ID","Borrow Date","Return Date","Status"},0);

        try {
            String sql = "SELECT * FROM LOAN WHERE student_id=? AND MONTH(borrow_date)=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, studentId);
            ps.setInt(2, month);

            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                model.addRow(new Object[]{
                    rs.getString("book_id"),
                    rs.getDate("borrow_date"),
                    rs.getDate("return_date"),
                    rs.getString("status")
                });
            }
        } catch(Exception e){ e.printStackTrace(); }

        return new JTable(model);
    }
}

