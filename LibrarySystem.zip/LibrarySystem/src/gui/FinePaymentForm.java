/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui;

/**
 *
 * @author Vihanga Ranaweera
 */
import service.LibraryService;
import javax.swing.*;
import java.awt.*;

public class FinePaymentForm extends JFrame {

    JTextField txtStudent = new JTextField();
    JTextField txtAmount = new JTextField();
    JButton btnPay = new JButton("Pay Fine");

    public FinePaymentForm(LibraryService service) {

        setLayout(new GridLayout(3,2));

        add(new JLabel("Student ID"));
        add(txtStudent);
        add(new JLabel("Amount"));
        add(txtAmount);
        add(btnPay);

        btnPay.addActionListener(e -> {
            service.payFine(
                txtStudent.getText(),
                Double.parseDouble(txtAmount.getText())
            );
            JOptionPane.showMessageDialog(this, "Fine Paid Successfully");
        });

        setTitle("Fine Payment");
        setSize(300,200);
        setVisible(true);
    }
}

