/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui;

/**
 * GUI Form for displaying loan history reports.
 * Part of 3-Tier Architecture: Presentation Layer
 * Works with both MySQL (ReportDAOMySQL) and MongoDB (ReportDAOMongo) backends.
 *
 * @author Vihanga Ranaweera
 */
import dao.ReportDAO;
import java.awt.*;
import javax.swing.*;

public class LoanReportForm extends JFrame {

    JTextField txtStudent = new JTextField();
    JTextField txtMonth = new JTextField();
    JButton btnView = new JButton("View Report");
    JPanel panel = new JPanel();

    public LoanReportForm(ReportDAO dao) {

        setLayout(new BorderLayout());

        JPanel top = new JPanel(new GridLayout(1,5));
        top.add(new JLabel("Student ID"));
        top.add(txtStudent);
        top.add(new JLabel("Month (1-12)"));
        top.add(txtMonth);
        top.add(btnView);

        add(top, BorderLayout.NORTH);
        add(panel, BorderLayout.CENTER);

        btnView.addActionListener(e -> {
            panel.removeAll();
            panel.add(new JScrollPane(
                dao.getLoanHistory(
                    txtStudent.getText(),
                    Integer.parseInt(txtMonth.getText())
                )
            ));
            panel.revalidate();
        });
        setTitle("Loan Report");
        setSize(600,300);
        setVisible(true);
    }
}

