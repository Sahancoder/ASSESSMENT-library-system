/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui;

/**
 *
 * @author Vihanga Ranaweera
 */
import service.LibraryService;
import javax.swing.*;
import java.awt.*;

public class BorrowForm extends JFrame {

    JTextField txtStudent = new JTextField();
    JTextField txtBook = new JTextField();
    JButton btnBorrow = new JButton("Borrow");
    JButton btnReturn = new JButton("Return");

    public BorrowForm(LibraryService service) {

        setLayout(new GridLayout(3,2));

        add(new JLabel("Student ID"));
        add(txtStudent);
        add(new JLabel("Book ID"));
        add(txtBook);
        add(btnBorrow);
        add(btnReturn);

        btnBorrow.addActionListener(e ->
            service.borrowBook(txtStudent.getText(), txtBook.getText())
        );

        btnReturn.addActionListener(e ->
            service.returnBook(txtStudent.getText(), txtBook.getText())
        );

        setTitle("Library System");
        setSize(300,200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
}
