/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui;

/**
 * GUI Form for displaying fine payment reports.
 * Part of 3-Tier Architecture: Presentation Layer
 * Works with both MySQL (FineReportDAOMySQL) and MongoDB (FineReportDAOMongo) backends.
 *
 * @author Vihanga Ranaweera
 */
import dao.FineReportDAO;
import java.awt.*;
import javax.swing.*;

public class FineReportForm extends JFrame {

    JTextField txtStudent = new JTextField();
    JTextField txtMonth = new JTextField();
    JButton btnView = new JButton("View Total");

    public FineReportForm(FineReportDAO dao) {

        setLayout(new GridLayout(3,2));

        add(new JLabel("Student ID"));
        add(txtStudent);
        add(new JLabel("Month"));
        add(txtMonth);
        add(btnView);

        btnView.addActionListener(e -> {
            double total = dao.getTotalFine(
                txtStudent.getText(),
                Integer.parseInt(txtMonth.getText())
            );
            JOptionPane.showMessageDialog(this, "Total Fine: " + total);
        });
        setTitle("Fine Report");
        setSize(300,200);
        setVisible(true);
    }
}

