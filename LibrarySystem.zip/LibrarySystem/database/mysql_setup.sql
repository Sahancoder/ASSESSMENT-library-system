-- ============================================
-- Library Database System - MySQL Setup Script
-- ============================================
-- This script creates the database schema for the Library System
-- Demonstrates Relational Database Modeling with normalized tables
-- 
-- Author: Vihanga Ranaweera
-- ============================================

-- Create database
CREATE DATABASE IF NOT EXISTS library_db;
USE library_db;

-- ============================================
-- Table: STUDENT
-- Stores student information (normalized entity)
-- ============================================
CREATE TABLE IF NOT EXISTS STUDENT (
    student_id VARCHAR(20) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    phone VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- Table: BOOK  
-- Stores book information (normalized entity)
-- ============================================
CREATE TABLE IF NOT EXISTS BOOK (
    book_id VARCHAR(20) PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    author VARCHAR(100),
    isbn VARCHAR(20),
    available BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- Table: LOAN
-- Stores book borrowing/returning transactions
-- Foreign keys enforce referential integrity (relational model advantage)
-- ============================================
CREATE TABLE IF NOT EXISTS LOAN (
    loan_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(20) NOT NULL,
    book_id VARCHAR(20) NOT NULL,
    borrow_date DATE NOT NULL,
    return_date DATE,
    status VARCHAR(20) DEFAULT 'Borrowed',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Foreign key constraints - ensures data integrity
    FOREIGN KEY (student_id) REFERENCES STUDENT(student_id) 
        ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (book_id) REFERENCES BOOK(book_id) 
        ON DELETE CASCADE ON UPDATE CASCADE,
    
    -- Index for faster queries by student and date
    INDEX idx_student_date (student_id, borrow_date)
);

-- ============================================
-- Table: FINE_PAYMENT
-- Stores fine payment transactions
-- Demonstrates one-to-many relationship with STUDENT
-- ============================================
CREATE TABLE IF NOT EXISTS FINE_PAYMENT (
    payment_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(20) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_date DATE NOT NULL,
    reason VARCHAR(200),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Foreign key constraint
    FOREIGN KEY (student_id) REFERENCES STUDENT(student_id) 
        ON DELETE CASCADE ON UPDATE CASCADE,
    
    -- Index for faster queries by student and date
    INDEX idx_student_payment (student_id, payment_date)
);

-- ============================================
-- Sample Data for Testing
-- ============================================

-- Insert sample students
INSERT INTO STUDENT (student_id, name, email, phone) VALUES
('S001', 'John Smith', 'john.smith@university.edu', '555-0101'),
('S002', 'Jane Doe', 'jane.doe@university.edu', '555-0102'),
('S003', 'Bob Wilson', 'bob.wilson@university.edu', '555-0103');

-- Insert sample books
INSERT INTO BOOK (book_id, title, author, isbn) VALUES
('B001', 'Introduction to Algorithms', 'Thomas Cormen', '978-0262033848'),
('B002', 'Database System Concepts', 'Abraham Silberschatz', '978-0073523323'),
('B003', 'Clean Code', 'Robert Martin', '978-0132350884'),
('B004', 'Design Patterns', 'Gang of Four', '978-0201633610');

-- Insert sample loans
INSERT INTO LOAN (student_id, book_id, borrow_date, return_date, status) VALUES
('S001', 'B001', '2025-12-01', '2025-12-15', 'Returned'),
('S001', 'B002', '2025-12-10', NULL, 'Borrowed'),
('S002', 'B003', '2025-12-05', '2025-12-20', 'Returned'),
('S003', 'B004', '2025-12-15', NULL, 'Borrowed');

-- Insert sample fine payments
INSERT INTO FINE_PAYMENT (student_id, amount, payment_date, reason) VALUES
('S001', 5.00, '2025-12-16', 'Late return - B001'),
('S002', 2.50, '2025-12-21', 'Late return - B003'),
('S001', 3.00, '2025-12-20', 'Damaged book cover');

-- ============================================
-- Useful Queries for Reports
-- ============================================

-- Query: Get loan history for a student in a specific month
-- SELECT * FROM LOAN WHERE student_id = 'S001' AND MONTH(borrow_date) = 12;

-- Query: Get total fine paid by a student in a specific month  
-- SELECT SUM(amount) FROM FINE_PAYMENT WHERE student_id = 'S001' AND MONTH(payment_date) = 12;

-- ============================================
-- Comparison with MongoDB (NoSQL)
-- ============================================
-- In MongoDB, the same data would be stored as documents:
--
-- loans collection:
-- {
--   "_id": ObjectId("..."),
--   "studentId": "S001",
--   "bookId": "B001", 
--   "borrowDate": "2025-12-01",
--   "returnDate": "2025-12-15",
--   "status": "Returned"
-- }
--
-- Key differences:
-- 1. No foreign keys - MongoDB uses embedded documents or references
-- 2. No strict schema - documents can have different fields
-- 3. No JOINs - denormalization is common
-- 4. Horizontal scaling is easier in MongoDB
-- ============================================
